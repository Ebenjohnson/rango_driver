import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/concatMap';
import { Observable } from "rxjs/Observable";
import { APP_CONFIG, AppConfig } from "../app/app.config";
import { Country } from '../models/country.models';
import { ResetPasswordResponse } from '../models/reset-password-request.models';
import { AuthResponse } from '../models/auth-response.models';
import { SignInRequest } from '../models/signin-request.models';
import { SignUpRequest } from '../models/signup-request.models';
import { Setting } from '../models/setting.models';
import { SupportRequest } from '../models/support-request.models';
import { PaymentMethod } from '../models/payment-methods.models';
import { BankDetail } from '../models/bank-details.models';
import { Constants } from '../models/constants.models';
import { Order } from '../models/order.models';
import { EarningResponse } from '../models/earning-response.models';
import { Profile } from '../models/profile.models';
import { BaseListResponse } from '../models/base-list.models';
import { Helper } from '../models/helper.models';
import moment from 'moment';

@Injectable()
export class ClientService {
  private myHeaders: HttpHeaders;

  constructor(@Inject(APP_CONFIG) private config: AppConfig, private http: HttpClient) {
    this.setupHeaders();
  }

  setupHeaders(authToken?: string) {
    //let savedLanguageCode = window.localStorage.getItem(Constants.KEY_DEFAULT_LANGUAGE);
    let token = authToken ? authToken : window.localStorage.getItem(Constants.KEY_TOKEN);
    this.myHeaders = new HttpHeaders(token ? {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': ('Bearer ' + token)
      //,'X-Localization': String(savedLanguageCode ? savedLanguageCode : this.config.availableLanguages[0].code)
    } : {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        //,'X-Localization': String(savedLanguageCode ? savedLanguageCode : this.config.availableLanguages[0].code)
      });
  }

  public getCountries(): Observable<Array<Country>> {
    return this.http.get<Array<Country>>('./assets/json/countries.json').concatMap((data) => {
      return Observable.of(data);
    });
  }

  public getPaymentMethods(): Observable<Array<PaymentMethod>> {
    return this.http.get<Array<PaymentMethod>>(this.config.apiBase + "api/customer/payment-methods", { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getSettings(): Observable<Array<Setting>> {
    return this.http.get<Array<Setting>>(this.config.apiBase + "api/settings", { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getBankDetail(): Observable<BankDetail> {
    return this.http.get<BankDetail>(this.config.apiBase + 'api/bank-detail', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getEarnings(): Observable<EarningResponse> {
    return this.http.get<EarningResponse>(this.config.apiBase + "api/earnings", { headers: this.myHeaders }).concatMap(data => {
      data.total_earnings = Number(data.total_earnings.toFixed(2));
      for (let e of data.earnings.data) {
        e.created_at_date = moment(e.created_at).toDate();
      }
      return Observable.of(data);
    });
  }

  public forgetPassword(resetRequest: any): Observable<ResetPasswordResponse> {
    return this.http.post<ResetPasswordResponse>(this.config.apiBase + "api/forgot-password", JSON.stringify(resetRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public login(loginRequest: SignInRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/login", JSON.stringify(loginRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public loginSocial(socialLoginRequest: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/social/login", JSON.stringify(socialLoginRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public signUp(signUpRequest: SignUpRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/register", JSON.stringify(signUpRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public contactUs(obj): Observable<SupportRequest> {
    return this.http.post<SupportRequest>(this.config.apiBase + 'api/support', obj, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public saveBankDetails(obj): Observable<BankDetail> {
    return this.http.post<BankDetail>(this.config.apiBase + 'api/bank-detail', obj, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public updateDeliveryProfile(obj): Observable<Profile> {
    return this.http.put<Profile>(this.config.apiBase + 'api/delivery/profile/update', obj, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getDeliveryProfile(): Observable<Profile> {
    return this.http.get<Profile>(this.config.apiBase + 'api/delivery/profile', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getCurrentOrder(): Observable<Order> {
    return this.http.get<Order>(this.config.apiBase + 'api/delivery/order', { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      data.created_at = this.formatDateTime(data.created_at, locale);
      data.updated_at = this.formatDateTime(data.updated_at, locale);
      return Observable.of(data);
    });
  }

  public updateOrderStatus(status: string, id): Observable<Order> {
    return this.http.put<Order>(this.config.apiBase + 'api/delivery/update-delivery-status/' + id, { delivery_status: status }, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public updateUser(updateRequest): Observable<{}> {
    return this.http.put<{}>(this.config.apiBase + 'api/user', updateRequest, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public verifyMobile(verifyRequest: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/verify-mobile", JSON.stringify(verifyRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public ordersDelivery(pageNo: number): Observable<BaseListResponse> {
    return this.http.get<BaseListResponse>(this.config.apiBase + "api/delivery/my-orders?page=" + pageNo, { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      for (let o of data.data) {
        o.created_at = this.formatDate(o.created_at, locale);
        o.updated_at = this.formatDate(o.updated_at, locale);
      }
      return Observable.of(data);
    });
  }

  public deliveryPaymentHistory(pageNo: number): Observable<BaseListResponse> {
    return this.http.get<BaseListResponse>(this.config.apiBase + "api/delivery/my-payment-history?page=" + pageNo, { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      for (let dph of data.data) {
        dph.created_at = this.formatDateTime(dph.created_at, locale);
        dph.updated_at = this.formatDateTime(dph.updated_at, locale);
      }
      return Observable.of(data);
    });
  }

  private formatDateTime(dateString: string, locale: string): string {
    return moment(dateString).locale(locale).format("ddd, MMM D, HH:mm");
  }

  private formatDate(dateString: string, locale: string): string {
    return moment(dateString).locale(locale).format("DD MMM YYYY");
  }
  public getWhatsappDetails(): Observable<Array<Setting>> {
    const myHeaders = new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' });
    return this.http.get<Array<Setting>>('https://dashboard.vtlabs.dev/whatsapp.php?product_name=cookfu', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }
}