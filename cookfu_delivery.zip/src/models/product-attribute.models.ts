export class ProductAttribute {
    id: string;
    name: string;
    option: string;
}