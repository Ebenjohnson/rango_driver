export class Constants {
	static KEY_USER: string = "kd_user";
	static KEY_PROFILE: string = "kd_profile";
	static KEY_TOKEN: string = "kd_token";
	static KEY_SETTING: string = "kd_setting";
	static KEY_LOCATION: string = "kd_location";
	static SELECTED_STORE: string = "kd_ss";
	static PAYMENT_GATEWAYS: string = "kd_pgs";
	static KEY_DEFAULT_LANGUAGE: string = "kd_def_lng";
	static KEY_LOCALE: string = "kd_locale";
}