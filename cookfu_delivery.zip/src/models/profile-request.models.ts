export class ProfileRequest {
  latitude: string;
  longitude: string;
  is_online: boolean;
}