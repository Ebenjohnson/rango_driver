export class PaymentMethod {
  created_at: string;
  id: number;
  slug: string;
  title: string;
  updated_at: string;
}