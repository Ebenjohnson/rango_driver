import { Component, ViewChild, ElementRef } from '@angular/core';
import { Events, AlertController, ModalController, NavController } from 'ionic-angular';
import { Constants } from '../../models/constants.models';
import { Profile } from '../../models/profile.models';
import { Order } from '../../models/order.models';
import { MyLocation } from '../../models/my-location.models';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs/Subscription';
import { Global } from '../../providers/global';
import { ClientService } from '../../providers/client.service';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Geolocation } from '@ionic-native/geolocation';
import { Helper } from '../../models/helper.models';
import { GoogleMaps } from '../../providers/google-maps';
import { Call_nowPage } from '../call_now/call_now';
import { OrdersinfoPage } from '../ordersinfo/ordersinfo';
import * as firebase from 'firebase/app';

declare var google;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild('map') private mapElement: ElementRef;
  @ViewChild('pleaseConnect') private pleaseConnect: ElementRef;
  private profile: Profile;
  private order: Order;
  private subscriptions = new Array<Subscription>();
  private currency: string;
  private online = true;
  private refreshingOrder = false;
  private distance: string = "--";
  private duration: string = "--";
  private location: MyLocation;
  private markerMe: any;
  private markerStore: any;
  private markerCustomer: any;
  private initialized: boolean;
  private watchLocationIntervalId;

  constructor(private translate: TranslateService, private maps: GoogleMaps, private navCtrl: NavController,
    private global: Global, private service: ClientService, events: Events, private modalCtrl: ModalController,
    private diagnostic: Diagnostic, private alertCtrl: AlertController, private geolocation: Geolocation) {
    this.profile = JSON.parse(window.localStorage.getItem(Constants.KEY_PROFILE));
    this.currency = Helper.getSetting("currency");
    this.location = JSON.parse(window.localStorage.getItem(Constants.KEY_LOCATION));
    if (!this.location) { this.location = new MyLocation(); }
    if (this.profile) {
      this.online = this.profile.is_online == 1;
      if (this.online) this.refreshOrder();
    } else {
      this.online = true;
      this.toggleOnline();
    }
    events.subscribe('order:fetch', () => {
      this.refreshOrder();
    });
  }

  ionViewDidLoad() {
    if (!this.initialized) {
      let mapLoaded = this.maps.init(this.mapElement.nativeElement, this.pleaseConnect.nativeElement).then(() => {
        // this.maps.map.addListener('click', (event) => {
        //   if (event && event.latLng) { }
        // });
        this.initialized = true;
      }).catch(err => {
        console.log(err);
      });
      mapLoaded.catch(err => {
        console.log(err);
      });
    }
  }

  ionViewDidEnter() {
    this.diagnostic.isLocationEnabled().then((isAvailable) => {
      if (isAvailable) {
        if (this.order && this.order.delivery_status == 'started' && !this.watchLocationIntervalId) {
          this.watchLocation();
        } else {
          const component = this;
          this.geolocation.getCurrentPosition().then((resp) => {
            if (!component.location) component.location = new MyLocation();
            component.location.lat = String(resp.coords.latitude);
            component.location.lng = String(resp.coords.longitude);
            window.localStorage.setItem(Constants.KEY_LOCATION, JSON.stringify(component.location));

            component.distanceMatrix();

            component.subscriptions.push(component.service.updateDeliveryProfile({
              is_online: component.online,
              longitude: component.location.lng,
              latitude: component.location.lat
            }).subscribe(res => {
              component.profile = res;
              window.localStorage.setItem(Constants.KEY_PROFILE, JSON.stringify(res));
              if (res.is_online == 1 && !component.refreshingOrder && (!component.order || !component.order.id || component.order.status == "complete")) {
                component.refreshOrder();
              }
            }, err => {
              console.log('updateDeliveryProfile', JSON.stringify(err));
            }));

            if (component.maps.map) {
              let center = new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude);
              if (component.markerMe) {
                component.markerMe.setPosition(center);
              } else {
                component.markerMe = new google.maps.Marker({
                  position: center,
                  map: component.maps.map,
                  title: 'You are here!',
                  icon: 'assets/imgs/track_delivery.png'
                });

                let infoFood = new google.maps.InfoWindow({
                  content: "You are here!"
                });
                this.markerMe.addListener('click', function () {
                  infoFood.open(component.maps.map, component.markerMe);
                });
              }
              setTimeout(() => {
                component.maps.map.panTo(center);
              }, 1000);
            }

          }).catch((error) => {
            console.log('Error getting location', JSON.stringify(error));
          });
        }
      } else {
        this.alertLocationServices();
      }
    }).catch((e) => {
      console.error(e);
      this.alertLocationServices();
    });
  }

  ionViewWillLeave() {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    if (this.watchLocationIntervalId) {
      clearInterval(this.watchLocationIntervalId);
      this.watchLocationIntervalId = null;
    }
    this.global.dismissLoading();
  }

  callNow() {
    let modal = this.modalCtrl.create(Call_nowPage, { order: this.order });
    modal.present();
  }

  toggleOnline() {
    this.translate.get('just_a_mmnt').subscribe(value => {
      this.global.presentLoading(value);
      this.subscriptions.push(this.service.updateDeliveryProfile({ is_online: this.online }).subscribe(res => {
        this.profile = res;
        window.localStorage.setItem(Constants.KEY_PROFILE, JSON.stringify(res));
        if (res.is_online == 1) {
          if (!this.refreshingOrder) {
            this.refreshOrder();
          } else {
            this.global.dismissLoading();
          }
        } else {
          this.global.dismissLoading();
        }
      }, err => {
        console.log('updateDeliveryProfile', JSON.stringify(err));
        this.global.showToast("Unable to toggle availability at the moment");
        this.global.dismissLoading();
      }));
    });
  }

  distanceMatrix() {
    if (this.order && this.location) {
      const component = this;
      let distance_metric = Helper.getSetting("distance_metric");
      let distanceMatrixRequest: any;
      if (distance_metric && distance_metric.length) {
        distanceMatrixRequest = {
          origins: [new google.maps.LatLng(Number(this.location.lat), Number(this.location.lng))],
          destinations: [new google.maps.LatLng(Number(this.order.delivery_status == "started" ? this.order.address.latitude : this.order.store.latitude), Number(this.order.delivery_status == "started" ? this.order.address.longitude : this.order.store.longitude))],
          travelMode: "DRIVING",
          unitSystem: distance_metric.toLowerCase() == "mi" ? google.maps.UnitSystem.METRIC : google.maps.UnitSystem.IMPERIAL
        };
      } else {
        distanceMatrixRequest = {
          travelMode: "DRIVING",
          origins: [new google.maps.LatLng(Number(this.location.lat), Number(this.location.lng))],
          destinations: [new google.maps.LatLng(Number(this.order.delivery_status == "started" ? this.order.address.latitude : this.order.store.latitude), Number(this.order.delivery_status == "started" ? this.order.address.longitude : this.order.store.longitude))]
        };
      }
      let distanceMatrixService = new google.maps.DistanceMatrixService();
      distanceMatrixService.getDistanceMatrix(distanceMatrixRequest, function (result, status) {
        if (status == google.maps.DirectionsStatus.OK) {
          console.log("distanceMatrix", JSON.stringify(result));
          if (result.rows && result.rows[0] && result.rows[0].elements && result.rows[0].elements[0]) {
            component.duration = result.rows[0].elements[0].duration.text;
            component.distance = result.rows[0].elements[0].distance.text;
          }
        }
      });
    }
  }

  refreshOrder() {
    this.refreshingOrder = true;
    this.subscriptions.push(this.service.getCurrentOrder().subscribe(res => {
      this.refreshingOrder = false;
      this.global.dismissLoading();
      if (res.status == "complete") {
        this.order = null;
        this.translate.get('no_order').subscribe(value => {
          this.global.showToast(value);
        });
      } else {
        if (!this.order || this.order.id != res.id || this.order.status != res.status) {
          this.order = res;
          if (res.delivery_status == "allotted") {
            this.translate.get(res.status == "dispatched" ? "dispatched" : "dispatched_not").subscribe(value => {
              this.global.showToast(value);
            });
          }
          this.checkAndSetMarkers();
          this.ionViewDidEnter();
        }
      }
    }, err => {
      this.refreshingOrder = false;
      this.global.dismissLoading();
      console.log('getCurrentOrder', JSON.stringify(err));
      let toastMessage: string;
      this.translate.get('no_order_err').subscribe(value => {
        toastMessage = value;
      });
      if (err.status == 404) {
        this.translate.get('no_order').subscribe(value => {
          toastMessage = value;
        });
      }
      this.global.showToast(toastMessage);
    }));
  }

  updateOrder() {
    console.log(this.order);
    if (this.order) {
      switch (this.order.delivery_status) {
        case "allotted":
          this.translate.get("just_a_mmnt").subscribe(value => {
            this.global.showToast(value);
          });
          this.refreshingOrder = true;
          this.subscriptions.push(this.service.getCurrentOrder().subscribe(res => {
            this.refreshingOrder = false;
            this.global.dismissLoading();
            if (res.status == "complete") {
              this.order = null;
              this.translate.get('no_order').subscribe(value => {
                this.global.showToast(value);
              });
            } else {
              if (!this.order || this.order.id != res.id || this.order.status != res.status) {
                this.order = res;
              }
              if (this.order.status == "dispatched") {
                this.updateOrderStatus("started");
              } else {
                this.translate.get("dispatched_not").subscribe(value => {
                  this.global.showToast(value);
                });
              }
            }
          }, err => {
            this.refreshingOrder = false;
            this.global.dismissLoading();
            console.log('getCurrentOrder', JSON.stringify(err));
            let toastMessage: string;
            this.translate.get('no_order_err').subscribe(value => {
              toastMessage = value;
            });
            if (err.status == 404) {
              this.translate.get('no_order').subscribe(value => {
                toastMessage = value;
              });
            }
            this.global.showToast(toastMessage);
          }));
          break;
        case "started":
          this.updateOrderStatus("complete");
          break;
      }
    }
  }

  updateOrderStatus(toUpdate) {
    if (toUpdate) {
      this.translate.get('loading').subscribe(value => {
        this.global.presentLoading(value);
        this.subscriptions.push(this.service.updateOrderStatus(toUpdate, this.order.id).subscribe(res => {
          if (res.status == "complete") {
            if (this.watchLocationIntervalId) {
              clearInterval(this.watchLocationIntervalId);
              this.watchLocationIntervalId = null;
            }
            this.order = null;
            this.translate.get('completed').subscribe(value => {
              this.global.showToast(value);
            });
          } else {
            this.order = res;
            if (this.order.delivery_status == 'started') {
              this.diagnostic.isLocationEnabled().then((isAvailable) => {
                if (isAvailable) {
                  this.watchLocation();
                } else {
                  this.alertLocationServices();
                }
              }).catch((e) => {
                console.error(e);
                this.alertLocationServices();
              });
            } else {
              if (this.watchLocationIntervalId) {
                clearInterval(this.watchLocationIntervalId);
                this.watchLocationIntervalId = null;
              }
            }
          }
          this.global.dismissLoading();
        }, err => {
          this.global.dismissLoading();
          console.log('updateOrderStatus', JSON.stringify(err));
          if (!this.refreshingOrder) {
            this.refreshOrder();
          }
        }));
      });
    }
  }

  orderInfo() {
    if (this.order) this.navCtrl.push(OrdersinfoPage, { order: this.order });
  }

  watchLocation() {
    if (!this.watchLocationIntervalId) {
      this.watchLocationIntervalId = setInterval(() => {
        console.log("watchinglocation");
        const component = this;
        component.geolocation.getCurrentPosition({ enableHighAccuracy: true }).then((resp) => {
          console.log("CurrentPosition", resp);
          if (!component.location) component.location = new MyLocation();
          component.location.lat = String(resp.coords.latitude);
          component.location.lng = String(resp.coords.longitude);

          component.distanceMatrix();

          window.localStorage.setItem(Constants.KEY_LOCATION, JSON.stringify(component.location));

          firebase.database().ref().child("cookfu").child(String(component.order.id)).set(component.location);

          component.subscriptions.push(component.service.updateDeliveryProfile({
            is_online: component.online,
            longitude: component.location.lng,
            latitude: component.location.lat
          }).subscribe(res => {
            console.log('updateDeliveryProfile', JSON.stringify(res));
          }, err => {
            console.log('updateDeliveryProfile', JSON.stringify(err));
            component.global.showToast("Unable to toggle availability at the moment");
            component.global.dismissLoading();
          }));

          if (component.maps.map) {
            let center = new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude);
            if (component.markerMe) {
              component.markerMe.setPosition(center);
            } else {
              component.markerMe = new google.maps.Marker({
                position: center,
                map: component.maps.map,
                title: 'You are here!',
                icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
              });

              let infoFood = new google.maps.InfoWindow({
                content: "You are here!"
              });
              this.markerMe.addListener('click', function () {
                infoFood.open(component.maps.map, component.markerMe);
              });
            }
            setTimeout(() => {
              component.maps.map.panTo(center);
            }, 500);
          }
        }).catch((error) => {
          console.log("CurrentPosition", error);
        });
      }, 15000);
    }
  }

  alertLocationServices() {
    this.translate.get(['location_services_title', 'location_services_message', 'okay']).subscribe(text => {
      let alert = this.alertCtrl.create({
        title: text['location_services_title'],
        subTitle: text['location_services_message'],
        buttons: [{
          text: text['okay'],
          role: 'cancel',
          handler: () => {
            console.log('okay clicked');
          }
        }]
      });
      alert.present();
    })
  }

  navigateOrRefresh() {
    if (this.order) {
      this.navigateMe();
    } else {
      this.online = true;
      this.toggleOnline();
    }
  }

  navigateMe() {
    if (this.order) {
      let toGoTo = this.getLatLngNavTo();
      if (toGoTo != null) {
        let openUrl = this.location ? ("https://www.google.com/maps/dir/?api=1&origin=" + this.location.lat + "," + this.location.lng + "&destination=" + toGoTo.lat + "," + toGoTo.lng) : ("https://maps.google.com/?q=" + toGoTo.lat + "," + toGoTo.lng);
        console.log("openUrl", openUrl);
        window.open(openUrl, '_system', 'location=yes');
      }
    }
  }

  getLatLngNavTo(): MyLocation {
    let latLng = null;
    if (this.order != null) {
      if (this.order.delivery_status == "started") {
        if (this.order.address != null && this.order.address.latitude != null && this.order.address.longitude != null) {
          latLng = new MyLocation();
          latLng.lat = this.order.address.latitude;
          latLng.lng = this.order.address.longitude;
        } else {
          this.translate.get("address_unavailable_user").subscribe(value => this.global.showToast(value));
        }
      } else {
        if (this.order.store != null && this.order.store.latitude != null && this.order.store.longitude != null) {
          latLng = new MyLocation();
          latLng.lat = this.order.store.latitude;
          latLng.lng = this.order.store.longitude;
        } else {
          this.translate.get("address_unavailable_store").subscribe(value => this.global.showToast(value));
        }
      }
    }
    return latLng;
  }

  checkAndSetMarkers() {
    if (this.maps.map && this.order) {
      let store = null;
      const component = this;
      if (this.order.store && this.order.store.latitude && this.order.store.longitude)
        store = new google.maps.LatLng(this.order.store.latitude, this.order.store.longitude);
      let customer = null;
      if (this.order.address && this.order.address.latitude && this.order.address.longitude)
        customer = new google.maps.LatLng(this.order.address.latitude, this.order.address.longitude);
      //this.map.panTo(center);
      if (store) {
        if (this.markerStore) {
          this.markerStore.setPosition(store);
        } else {
          this.markerStore = new google.maps.Marker({
            position: store,
            map: this.maps.map,
            title: 'Restaurant',
            icon: 'assets/imgs/track_store.png'
          });
          let infoStore = new google.maps.InfoWindow({
            content: "Restaurant"
          });
          this.markerStore.addListener('click', function () {
            infoStore.open(component.maps.map, component.markerStore);
          });
        }
        setTimeout(() => {
          this.maps.map.panTo(store);
        }, 1000);
      }
      if (customer) {
        if (this.markerCustomer) {
          this.markerCustomer.setPosition(customer);
        } else {
          this.markerCustomer = new google.maps.Marker({
            position: customer,
            map: this.maps.map,
            title: 'Customer',
            icon: 'assets/imgs/track_user.png'
          });

          let infoMe = new google.maps.InfoWindow({
            content: "Customer"
          });
          this.markerCustomer.addListener('click', function () {
            infoMe.open(component.maps.map, component.markerCustomer);
          });
        }
        setTimeout(() => {
          this.maps.map.panTo(customer);
        }, 1500);
      }
    }
  }

}