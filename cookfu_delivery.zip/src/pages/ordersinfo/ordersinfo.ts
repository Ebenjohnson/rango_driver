import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';
import { Subscription } from 'rxjs/Subscription';
import { Order } from '../../models/order.models';
import { CallNumber } from '@ionic-native/call-number';
import { Helper } from '../../models/helper.models';

@Component({
  selector: 'page-ordersinfo',
  templateUrl: 'ordersinfo.html'
})
export class OrdersinfoPage {
  private order: Order;
  private currency: string;
  private toUpdate: string = "accepted";
  private subscriptions = new Array<Subscription>();
  private message: string;

  constructor(private callNumber: CallNumber, private params: NavParams) {
    this.order = this.params.get("order");
    this.currency = Helper.getSetting("currency");
    console.log('order', this.order);
  }

  navUser() {
    window.open("https://www.google.com/maps?q=" + this.order.address.latitude + "," + this.order.address.longitude, "_blank");
  }

  dialNumber(number) {
    this.callNumber.callNumber(number, true).then(res => console.log('Launched dialer!', res)).catch(err => console.log('Error launching dialer', err));
  }

}