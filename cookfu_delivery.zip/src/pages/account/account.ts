import { Component, Inject } from '@angular/core';
import { NavController, AlertController, App } from 'ionic-angular';
import { ProfilePage } from '../profile/profile';
import { SigninPage } from '../signin/signin';
import { LanguagePage } from '../language/language';
import { BankdatailsPage } from '../bankdatails/bankdatails';
import { SupportPage } from '../support/support';
import { Constants } from '../../models/constants.models';
import { TranslateService } from '@ngx-translate/core';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { AppConfig, APP_CONFIG } from '../../app/app.config';
import { Global } from '../../providers/global';
import { ClientService } from '../../providers/client.service';

@Component({
  selector: 'page-account',
  templateUrl: 'account.html'
})
export class AccountPage {

  constructor(@Inject(APP_CONFIG) private config: AppConfig, public navCtrl: NavController, private alertCtrl: AlertController,
    private translate: TranslateService, private app: App, public inAppBrowser: InAppBrowser, private clientservice: ClientService,
    private global: Global, private service: ClientService) { }

  profile() {
    this.navCtrl.push(ProfilePage);
  }

  bankdatails() {
    this.navCtrl.push(BankdatailsPage);
  }

  contact() {
    this.navCtrl.push(SupportPage);
  }

  language() {
    this.navCtrl.push(LanguagePage);
  }

  phonenumberPage() {
    this.translate.get(['logout_title', 'logout_message', 'no', 'yes']).subscribe(text => {
      let alert = this.alertCtrl.create({
        title: text['logout_title'],
        message: text['logout_message'],
        buttons: [{
          text: text['no'],
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: text['yes'],
          handler: () => {
            window.localStorage.removeItem(Constants.KEY_TOKEN);
            window.localStorage.removeItem(Constants.KEY_USER);
            window.localStorage.removeItem(Constants.KEY_PROFILE);
            this.clientservice.setupHeaders(null);
            this.app.getRootNav().setRoot(SigninPage);
          }
        }]
      });
      alert.present();
    })
  }
  developedBy() {
    const options: InAppBrowserOptions = {
      zoom: 'no'
    }
    const browser = this.inAppBrowser.create('https://verbosetechlabs.com/', '_system', options);
  }
  buyThisApp() {
    this.translate.get('opening_WhatsApp').subscribe(text => {
      this.global.presentLoading(text);
      this.service.getWhatsappDetails().subscribe((res) => {
        this.global.dismissLoading();
        return this.inAppBrowser.create(res['link'], '_system');
      }, (err) => {
        console.log("Error rating:", JSON.stringify(err));
        this.global.dismissLoading();
      });
    });
  }
}
