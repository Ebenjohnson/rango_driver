import { Component } from '@angular/core';
import { NavController, ViewController, NavParams } from 'ionic-angular';
import { Order } from '../../models/order.models';
import { CallNumber } from '@ionic-native/call-number';

@Component({
  selector: 'page-call_now',
  templateUrl: 'call_now.html'
})
export class Call_nowPage {
  private order: Order;

  constructor(navParams: NavParams, private viewCtrl: ViewController, private callNumber: CallNumber) {
    this.order = navParams.get("order");
  }

  dialNumber(number) {
    this.callNumber.callNumber(number, true).then(res => console.log('Launched dialer!', res)).catch(err => console.log('Error launching dialer', err));
    this.dismiss();
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

}
