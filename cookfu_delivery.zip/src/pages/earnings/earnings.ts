import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { EarningResponse } from '../../models/earning-response.models';
import { Earning } from '../../models/earnings.models';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs/Subscription';
import { Global } from '../../providers/global';
import { ClientService } from '../../providers/client.service';
import { Helper } from '../../models/helper.models';
import moment from 'moment';

@Component({
  selector: 'page-earnings',
  templateUrl: 'earnings.html'
})
export class EarningsPage {
  private subscriptions = new Array<Subscription>();
  private currency: string;
  private earnings = new Array<Earning>();
  private earning = new EarningResponse();

  constructor(public navCtrl: NavController, private translate: TranslateService,
    private global: Global, private service: ClientService) {
    this.currency = Helper.getSetting("currency");
    console.log(JSON.stringify(this.currency));
  }

  ionViewDidEnter() {
    this.getEarnings();
  }

  getEarnings() {
    this.translate.get('loading').subscribe(value => {
      this.global.presentLoading(value);
      this.subscriptions.push(this.service.getEarnings().subscribe(res => {
        this.earning = res;
        if (!this.earning.last_earning_date) {
          this.earning.last_earning_date = String(new Date());
        }
        this.earning.last_earning_date = moment(this.earning.last_earning_date).format("DD MMM YYYY");
        this.earnings = res.earnings.data;
        this.global.dismissLoading();
      }, err => {
        this.global.dismissLoading();
        console.log('cat_err', err);
      }));
    });
  }

}