import { Component, Inject } from '@angular/core';
import { App, Events } from 'ionic-angular';
import { APP_CONFIG, AppConfig } from "../../app/app.config";
import { Constants } from '../../models/constants.models';
import { TabsPage } from '../tabs/tabs';

@Component({
  selector: 'page-language',
  templateUrl: 'language.html',
})
export class LanguagePage {
  private languageCode;

  constructor(@Inject(APP_CONFIG) private config: AppConfig, private app: App, private events: Events) {
    let defaultLangCode = this.config.availableLanguages[0].code;
    let savedLanguageCode = window.localStorage.getItem(Constants.KEY_DEFAULT_LANGUAGE);
    this.languageCode = savedLanguageCode ? savedLanguageCode : defaultLangCode;
  }

  set() {
    if (this.languageCode) {
      window.localStorage.setItem(Constants.KEY_DEFAULT_LANGUAGE, this.languageCode);
      this.events.publish("set:language", this.languageCode);
      this.app.getRootNav().setRoot(TabsPage);
    }
  }
}