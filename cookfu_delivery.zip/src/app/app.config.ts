import { InjectionToken } from "@angular/core";

export let APP_CONFIG = new InjectionToken<AppConfig>("app.config");

export interface FirebaseConfig {
  apiKey: string,
  authDomain: string,
  databaseURL: string,
  projectId: string,
  storageBucket: string,
  messagingSenderId: string,
  webApplicationId: string
}

export interface AppConfig {
  appName: string;
  apiBase: string;
  oneSignalAppId: string;
  oneSignalGPSenderId: string;
  googleApiKey: string;
  stripeKey: string;
  availableLanguages: Array<any>;
  firebaseConfig: FirebaseConfig;
  demoMode: boolean;
}

export const BaseAppConfig: AppConfig = {
  appName: "Cookfu delivery",
  apiBase: "https://cookfu.vtlabs.dev/",
  oneSignalAppId: "b3b83bae-6644-4db4-bc8d-fa27d300c1c6",
  oneSignalGPSenderId: "637446709495",
  googleApiKey: "AIzaSyC4xQ0n-BwL_gODzdOTI6eqmzABT7XtF9Y",
  stripeKey: "pk_live_REwn0xwFgQThJbX4Hi2gComm",
  demoMode: true,
  availableLanguages: [{
    code: 'en',
    name: 'English'
  }, {
    code: 'ar',
    name: 'Arabic'
  }],
  firebaseConfig: {
    webApplicationId: "637446709495-sn78ov9tjqlu7spekcdsns2o33p6fs29.apps.googleusercontent.com",
    apiKey: "AIzaSyC4xQ0n-BwL_gODzdOTI6eqmzABT7XtF9Y",
    authDomain: "dentist-58abe.firebaseapp.com",
    databaseURL: "https://dentist-58abe.firebaseio.com",
    projectId: "dentist-58abe",
    storageBucket: "dentist-58abe.appspot.com",
    messagingSenderId: "637446709495"
  }
};