import { Component, Inject, ViewChild } from '@angular/core';
import { Platform, App, Events, NavController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { OneSignal } from '@ionic-native/onesignal';
import { TabsPage } from '../pages/tabs/tabs';
import { SigninPage } from '../pages/signin/signin';
import { TranslateService } from '../../node_modules/@ngx-translate/core';
import { Constants } from '../models/constants.models';
import { User } from '../models/user.models';
import { APP_CONFIG, AppConfig } from "./app.config";
import { ClientService } from "../providers/client.service";
import { Global } from "../providers/global";
import { Subscription } from 'rxjs/Subscription';
import firebase from 'firebase';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild('myNav') navCtrl: NavController;
  private subscriptions = new Array<Subscription>();
  private user: User;

  constructor(@Inject(APP_CONFIG) private config: AppConfig, private service: ClientService,
    private platform: Platform, private statusBar: StatusBar, private splashScreen: SplashScreen,
    private translate: TranslateService, private oneSignal: OneSignal, private app: App, private events: Events) {
    this.initializeApp();
    this.events.subscribe("set:language", (languageCode) => {
      this.service.updateUser({ language: languageCode }).subscribe(res => console.log("langupdated", res), err => console.log("langupdateFailed", err));
      this.translate.use(languageCode);
      this.globalize(languageCode);
    });
    this.events.subscribe("event:user", (res) => {
      this.user = res;
      if (this.user) this.getPaymentMethods();
      if (this.user && this.platform.is('cordova')) this.updatePlayerId();
    });
  }

  refreshSettings() {
    this.service.getSettings().subscribe(res => {
      console.log('setting_setup_success', res);
      window.localStorage.setItem(Constants.KEY_SETTING, JSON.stringify(res));
    }, err => {
      console.log('setting_setup_error', err);
    });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.show();
      firebase.initializeApp({
        apiKey: this.config.firebaseConfig.apiKey,
        authDomain: this.config.firebaseConfig.authDomain,
        databaseURL: this.config.firebaseConfig.databaseURL,
        projectId: this.config.firebaseConfig.projectId,
        storageBucket: this.config.firebaseConfig.storageBucket,
        messagingSenderId: this.config.firebaseConfig.messagingSenderId
      });
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.user = JSON.parse(window.localStorage.getItem(Constants.KEY_USER));
      if (this.platform.is('cordova')) this.initOneSignal();
      this.refreshSettings();
      if (this.user) this.getPaymentMethods();

      this.app.getRootNav().setRoot(this.user ? TabsPage : SigninPage);
      setTimeout(() => {
        this.splashScreen.hide();
        if (this.user && this.platform.is('cordova'))
          this.updatePlayerId();
      }, 3000);

      let defaultLang = window.localStorage.getItem(Constants.KEY_DEFAULT_LANGUAGE);
      this.globalize(defaultLang);
    });
  }

  initOneSignal() {
    if (this.config.oneSignalAppId && this.config.oneSignalAppId.length && this.config.oneSignalGPSenderId && this.config.oneSignalGPSenderId.length) {
      this.oneSignal.startInit(this.config.oneSignalAppId, this.config.oneSignalGPSenderId);
      this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.Notification);
      this.oneSignal.handleNotificationReceived().subscribe((data) => {
        console.log(data);
      });
      this.oneSignal.handleNotificationOpened().subscribe((data) => {
        console.log(data);
      });
      this.oneSignal.endInit();
    }
  }

  updatePlayerId() {
    this.oneSignal.getIds().then((id) => {
      if (id && id.userId) {
        this.service.updateUser({ fcm_registration_id_driver: id.userId }).subscribe((res) => {
          console.log("playerIdReg", res);
        }, (err) => {
          console.log("playerIdNotReg", err);
        });
      }
    });
  }

  getPaymentMethods() {
    let subscription: Subscription = this.service.getPaymentMethods().subscribe(res => {
      window.localStorage.setItem(Constants.PAYMENT_GATEWAYS, JSON.stringify(res));
    }, err => {
      console.log('payment_method', err);
    });
    this.subscriptions.push(subscription);
  }

  globalize(languagePriority) {
    this.translate.setDefaultLang("en");
    let defaultLangCode = this.config.availableLanguages[0].code;
    this.translate.use(languagePriority && languagePriority.length ? languagePriority : defaultLangCode);
    this.setDirectionAccordingly(languagePriority && languagePriority.length ? languagePriority : defaultLangCode);
    window.localStorage.setItem(Constants.KEY_LOCALE, languagePriority && languagePriority.length ? languagePriority : defaultLangCode);
  }

  setDirectionAccordingly(lang: string) {
    switch (lang) {
      case 'ar': {
        this.platform.setDir('ltr', false);
        this.platform.setDir('rtl', true);
        break;
      }
      case 'iw': {
        this.platform.setDir('ltr', false);
        this.platform.setDir('rtl', true);
        break;
      }
      default: {
        this.platform.setDir('rtl', false);
        this.platform.setDir('ltr', true);
        break;
      }
    }
    // this.translate.use('pt');
    // this.platform.setDir('rtl', false);
    // this.platform.setDir('ltr', true);
    // this.rtlSide = "left";
  }

  getSideOfCurLang() {
    return this.platform.dir() === 'rtl' ? "right" : "left";
  }

  getSuitableLanguage(language, languageDefault) {
    language = language.substring(0, 2).toLowerCase();
    console.log('check for: ' + language);
    return this.config.availableLanguages.some(x => x.code == language) ? language : languageDefault;
  }
}